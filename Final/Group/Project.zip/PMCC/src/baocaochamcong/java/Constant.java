package baocaochamcong.java;

import java.time.LocalTime;

public class Constant {
    public static final LocalTime GIO_BAT_DAU_LAM_CA_SANG = LocalTime.of(8, 0, 0);
    public static final LocalTime GIO_KET_THUC_LAM_CA_SANG = LocalTime.of(12, 0, 0);
    public static final LocalTime GIO_BAT_DAU_LAM_CA_CHIEU = LocalTime.of(13, 0, 0);
    public static final LocalTime GIO_KET_THUC_LAM_CA_CHIEU = LocalTime.of(17, 0, 0);
    public static final LocalTime RANH_GIOI_SANG_CHIEU = LocalTime.of(12, 30, 0);

}
