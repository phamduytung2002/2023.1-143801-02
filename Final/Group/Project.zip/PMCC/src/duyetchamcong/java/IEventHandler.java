package duyetchamcong.java;

public interface IEventHandler<T> {
    void handle(T t);
}
