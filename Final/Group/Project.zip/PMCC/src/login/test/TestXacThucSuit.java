package login.test;


import org.junit.runner.RunWith;
import org.junit.runners.Suite;

//JUnit Suite unittest.Test
@RunWith(Suite.class)

@Suite.SuiteClasses({
        TestXacThucService1.class ,TestXacThucService2.class
})

public class TestXacThucSuit {
}
